import React from 'react';
import {Accounts} from '../components/accounts';

const accounts = () => {
   return <Accounts />;
};

export default accounts;
