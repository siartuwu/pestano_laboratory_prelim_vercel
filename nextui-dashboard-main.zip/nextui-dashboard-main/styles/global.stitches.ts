import {globalCss} from '@nextui-org/react';

export const globalStyles = globalCss({
   body: {
      fontFamily: 'Inter, sans-serif',
   },
});
