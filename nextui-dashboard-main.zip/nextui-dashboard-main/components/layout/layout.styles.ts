import {styled} from '@nextui-org/react';

export const WrapperLayout = styled('div', {
   display: 'flex',
});
